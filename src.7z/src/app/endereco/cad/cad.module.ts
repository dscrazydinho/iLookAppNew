import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CadPageRoutingModule } from './cad-routing.module';

import { CadPage } from './cad.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CadPageRoutingModule
  ],
  declarations: [CadPage]
})
export class CadPageModule {}

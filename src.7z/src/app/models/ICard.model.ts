export interface ICard {
  numero?: number;
  cvc?: number;
  validade?: Date;
}

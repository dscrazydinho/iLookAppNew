export interface IEnd {
  idEndereco?: any;
  cepEndereco?: string;
  streetEndereco?: string;
  neighEndereco?: string;
  cityEndereco?: string;
  ufEndereco?: string;
  numberEndereco?: string;
  compEndereco?: string;
  obsEndereco?: string;
}

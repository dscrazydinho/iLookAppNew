export interface IImage {

  idFile?: any;
  pathFile: string;
  nameFile: string;

}
